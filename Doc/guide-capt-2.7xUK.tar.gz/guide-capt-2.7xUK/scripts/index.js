window.onload = function fncOnLoad() {
	try {
		var wnd = window.open("frame_htmls/home.html", "_self");
		wnd.name = "canon_main_window";
	} catch (e) {
	}
}

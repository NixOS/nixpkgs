# test suite that always succeds - for testing framework

run()
{
	run_testcase true
	return 0
}
